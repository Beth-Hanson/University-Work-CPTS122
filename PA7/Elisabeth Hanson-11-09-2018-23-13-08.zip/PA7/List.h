/*Programmer: Beth Hanson
Class: CptS 122, Fall 2018
Programming Assignment: Project 7
File: List.h
Date: 10/30/18
Description: */

#pragma once
#include "Node.h"

template <class T>
class List {
public:
	List();
	~List();
	void insertAtFront(T newData);
	Node<T> *getHead();
	void setHead(Node<T> *newHead);
	//void printToFile(fstream &file);

private:
	Node<T> * pHead;
	void destroyList(Node<T> *pTemp);
};

template<class T>
List<T>::List() {
	this->pHead = nullptr;
}

template<class T>
List<T>::~List() {
	destroyList(this->pHead);
}

template<class T>
void List<T>::destroyList(Node<T> *pTemp) {
	if (pTemp != nullptr) {
		destroyList(pTemp->getNext());
		delete pTemp;
	}
}

template<class T>
void List<T>::insertAtFront(T newData) {
	Node<T> *pTemp = new Node<T>(newData);
	if (pTemp != nullptr) {
		pTemp->setNext(this->pHead);
		this->pHead = pTemp;
	}

}

template<class T>
Node<T>* List<T>::getHead() {
	return this->pHead;
}

template<class T>
void List<T>::setHead(Node<T> *newHead) {
	this->pHead = newHead;
}

//template<class T>
//void List<T>::printToFile(fstream &file) {
//	Node<T> *pTemp = this->pHead;
//	while (pTemp != nullptr) {
//		file << pTemp->getData() << endl;
//		pTemp = pTemp->getNext();
//	}
//}