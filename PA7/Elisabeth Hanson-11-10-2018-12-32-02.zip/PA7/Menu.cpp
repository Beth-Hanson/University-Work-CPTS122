/*Programmer: Beth Hanson
Class: CptS 122, Fall 2018
Programming Assignment: Project 7
File: Menu.cpp
Date: 10/30/18
Description: */

#include "Menu.h"

